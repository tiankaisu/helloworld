#!/usr/bin/python
#Supported by Walter Brown, Duo Liu

#Modified "cancel_like_terms(expression)" to make the items in dictionary in the same order as the sequence they are inserted
#Inserted splitDNF2terms(expression);
#BoolMult( opr1, opr2 )
#determCoef(Term, outerCoef)
#singleAndTermDistr( strExpr )
#expand_wo_elimination
# modified cancel_like_terms
#and_term_substitute(and_term, var2sub, eqn_right)




from subprocess import Popen, PIPE, STDOUT
import re
from collections import OrderedDict




def splitDNF2terms(expression):
	expression = expression.replace('-','+-')
	termList = [item for item in expression.split('+') if item != '']
	#return (term_list,len(term_list))
	return termList

#####################################################################

def get_all_variables(expression):
    """
    Returns a list of all variables in an expression.  Although the list isn't
    sorted, there are no redundant variables.
    """
    variable = ""
    all_vars = {"":True}
    for x in expression:
        if is_operator(x) or x == "(" or x == ")":
            if not represents_int(variable):
                all_vars[variable] = True
            variable =  ""
        else: variable += x
    if not represents_int(variable):
        all_vars[variable] = True
    del all_vars[""]
    return all_vars.keys()

#####################################################################
#RepresentsInt from http://stackoverflow.com/questions/1265665/python-check-if-a-string-represents-an-int-without-using-try-except
def represents_int(s):
    """
    Returns True if and only if s represents an integer.
    """
    try:
        int(s)
        return True
    except ValueError:
        return False

#####################################################################
def string_not_in(input_string, base ="a"):
    """
    Returns a string that is definately not in the input_string.  base will be
    repeated in the result.
    """
    result = base
    while result in input_string:
        result = result+base
    return result

########################################################
def substitute(expression, substitution):
    """
    Perform a substitution.  The solution is NOT necessarily distributed.
	Store variable in 'reading', once an operator or bracket is met,
    match reading with left side of substitution, if same, substitute
	reading with right side of substitution and set reading to nothing, else, copy the variable to result and keep matching.
	Notice: expression shall be an polynomial, NOT an equation!! Or else, the substitution may be wrong!!! 
    """
    split = substitution.split("=")
    #print split
    result = ""
    reading = ""
    for x in expression:
        if is_operator(x) or x == "(" or x == ")":
            if reading == split[0]: result += "(" + split[1] + ")"
            else: result += reading
            reading = ""
            result += x
        else:
            reading += x
	    #print "reading",reading
        #print "result",result
    if reading == split[0]: result += "(" + split[1] + ")"
    else: result += reading
    #print result
    return result
 
########################################################################   
def equation_to_polynomial(equation):
    """
    Moves one side of an equation to the other, returning just the polynomial
    without the equals sign.
    """
    match = re.search(r"(.*)=(.*)", equation)
    return match.group(2) + "-(" + match.group(1) + ")"

########################################################################
def order_boolean_variable_term(term_string):
    """
    Takes a term string, WITHOUT PARENTHISIS, and puts the term's variables in
    alphabetical order, with the coefficient in front.  * should be between all
    variables AND the coefficient.
    Examples:
    'x1*x2*-3*x1*2*x4'='-6*x1*x2*x4'
    '2*-3*7'='-42'
    ''=''
    """
    
    split = split_to_multipliers(term_string)    

    if not split : return ""
    
    #Grab all coefficients.
    coef = 1
    variables = {}
    for x in range(0, len(split)):
        if not split[x] : continue
        if represents_int(split[x]):
            coef *= int(split[x])
            continue
        #If there's a negative in front...
        if split[x][0] == "-" :
            coef *= -1
            variables[split[x][1:]] = True
        else :
            variables[split[x]] = True
            
    #ordered_vars = sorted(variables)
    compressed_vars = sorted(variables.keys())
    if not compressed_vars : return str(coef)
    result = "*".join(compressed_vars)
    if coef == -1 : return "-"+result
    if coef ==  1 : return result
    return str(coef) + "*" + result

#####################################################################3       
def coefficient(ordered_term_string):
    """
    Get integer coefficient of term where the coefficient is in front.
    """
    first_multiplier = ordered_term_string.split("*",1)[0]
    try:
        return int(first_multiplier)
    except ValueError:
        if first_multiplier and first_multiplier[0] == "-":
            return -1
        else:
            return 1
  
#############################################################  
def vars_only(ordered_term_string):
    """
    Returns the string of ordered variables without the coefficient in front.
    """
    split = ordered_term_string.split("*", 1)
    #If that first element is a coefficient, pop it away.
    if split and represents_int(split[0]):
        split.pop(0)
    if split:
        #Handle the -1 case.  Cut off the - in the beginning if it exists.
        if(split[0] and split[0][0] == "-"):
            split[0] = split[0][1:]
        #At this point, there are only variables here.
        return "*".join(split)
    else:
        return "1"
    
#####################################################################3
def split_to_terms(expression):
    """
    Turns a string, like a*b+c*-d-e*f+(g+h), into a list,
    like['a*b', 'c*-d', '-e*f', '(g+h)'].  Treats terms in parenthisis as one
    term. 
    """
    result = [""]
    paren_layer = 0
    for x in expression:
        if paren_layer == 0 and x == "+":
            result.append("")
        #Remember that - sometimes indicates sign, such as when it's after a *.
        elif paren_layer == 0 and x == "-" and result[-1] and \
        result[-1][-1] != "*":
            result.append("-")
        elif x == "(":
            paren_layer+=1
            result[-1]+="("
        elif x == ")":
            paren_layer-=1
            result[-1]+=")"
        else:
            result[-1]+=x
    return result
   
######################################################################## 
def merge_coefficient_and_vars(coefficient, variables):
    """
    Example:
    (4, "x2*x1*x7") -> "4*x2*x1*x7"
    """
    if variables == "1" : return str(coefficient)
    if coefficient == 1 : return variables
    if coefficient == -1 : return "-" + variables
    return str(coefficient) + "*" + variables
  
############################################################  
def list_to_expression(term_list):
    """
    Properly merges a set of terms, possibly signed, into a string expression
    """
    if not term_list : return "0"
    result = term_list.pop(0)
    for x in term_list:
        if x == "": continue
        if x[0] == "-": result += x
        else: result += "+" + x
    return result
            
#############################################################    
def cancel_like_terms(expression):
    """
    ("x1-x1")->"0"
    ("x1+x2-2x1")->"x2-x1"
    """
    #A dictionary is like a hash table.
    #dictionary = {}
    # To make the dictionary in the same order as how items are inserted:
    dictionary = OrderedDict()
    #terms = split_to_terms(expression)
    terms = splitDNF2terms(expression)
    #print terms
    for term in terms:
        #print term
        key = vars_only(term)
	#process coefficent:
        dictionary[key] = coefficient(term) + dictionary.get(key, 0)
    #dictionary = collections.OrderedDict()   
	#print dictionary
    #Now that everything is hashed, read off the hash.
    result_list = []
    for key in dictionary:
        if dictionary[key] != 0:
            result_list.append(merge_coefficient_and_vars(dictionary[key], key))
        #else: print "KILLED " + key + "."
    return list_to_expression(result_list)

###################################################################
def is_operator(character):
    return character == "+" or character == "-" or character == "*"



###################################################################
def insert_implicit_multiplication_signs(expression):
    """
    Sometimes, parenthisis indicate multiplication.  This will help in such
    cases.
    "(a+b)(c+d)" -> "(a+b)*(c+d)"
    "a(b+c)" -> "a*(b+c)"
    "(a+b)c" -> "(a+b)*c"
    """
    result = ""
    for x in range(0, len(expression)):
        if expression[x] == "(" and x != 0 and not is_operator(result[-1]) and \
        result[-1] != "(":
            result += "*"
        
        result += expression[x]
        
        if expression[x] == ")" and x != len(expression)-1 and \
        not is_operator(expression[x+1]) and expression[x+1] != ")":
            result += "*"
    return result

################################################################
def split_to_multipliers(term):
    """
    Takes a string for one term and breaks it into a list of the items being
    multiplied together.
    """
    paren_layer = 0
    left_index = 0
    right_index = 0
    result = []
    while right_index <= len(term):
        #Conditions in which to add the next block to the result.
        if right_index == len(term) or \
        paren_layer == 0 and term[right_index] == "*":
            result.append(term[left_index:right_index])
            left_index = right_index + 1
        elif term[right_index] == "(":
            paren_layer += 1
        elif term[right_index] == ")":
            paren_layer -= 1
        right_index += 1
    return result

########################################################################
def distribute_to_list(expression):
    """
    Takes an expression and distributes it to remove all parenthisis.
    """
    expression = expression.replace("-", "-1*")
    result_list = []
    #Handle each term on its own.
    outer_terms = split_to_terms(expression)
    #print "out_term",outer_terms
    for current_term in outer_terms:
        multipliers = split_to_multipliers(current_term)
        #print "multipliers",multipliers
        #Now, make sure that all multiplicitans are distributed.
        for i in range(0, len(multipliers)):
            #If a multiplicitan with parenthisis that need distribution...
            if multipliers[i][0]=="(":
                multipliers[i] = distribute_to_list(multipliers[i][1:-1])
            else:
                multipliers[i] = [multipliers[i]]
        #term_result is a running tally as the items get multiplied together. 
        term_result = ["1"]
        for multiplier in multipliers:
            new_term_result = []
            for multiplier_term in multiplier:
                for term_result_term in term_result:
                    new_term_result.append(multiplier_term + "*" +
                    term_result_term)
            term_result = new_term_result
        #At this point, term_result should contain all of the terms
        result_list+=term_result
    #print result_list
    for x in range(0, len(result_list)):
        result_list[x] = order_boolean_variable_term(result_list[x])
    return result_list
 
#########################################################   
def distribute(expression):
    """
    Returns a fully distributed string
    """
    return list_to_expression(distribute_to_list(expression))

##################################################################
def remove_extra_signs(expression):
    """
    Evaluates adjacent + and - signs to shrink the expression.
    """
    result = ""
    deciding_sign = False
    minus = False
    for x in expression:
        if x == "+":
            deciding_sign = True
        elif x == "-":
            deciding_sign = True
            minus = not minus
        else:
            if deciding_sign:
                if minus: result += "-"
                else: result += "+"
                deciding_sign = False
                minus = False
            result += x
    if result[0] == "+": return result[1:]
    else: return result

#############################################################
def simplify(expression, implied_multiplication = False):
    #I'm scared of spaces, so let's get rid of those first.
    result = expression.replace(" ", "")
    #Next, clear out unecessary addition and subtraction signs.
    result = remove_extra_signs(result)
    if implied_multiplication : 
        result = insert_implicit_multiplication_signs(result)
    #Distribute the expression out.
    result = distribute(result)
    #Now do cancelations
    result = cancel_like_terms(result)
    return result

#########################################################################
def clean_substitute(expression, substitution, implied_multiplication = False):
    """
    Uses the substitute method and the simplify method
    """
    return simplify(substitute(simplify(expression, implied_multiplication), substitution), implied_multiplication)

########################################################################3
def order_terms(expression):
    """
    Reorders terms in an expression string so they are in a standard ordering.
    """
    return list_to_expression(sorted(split_to_terms(expression), key=coefficient))
####################################################################################################3

def expand_wo_elimination (expression, substitution):
    V = substitute(expression,substitution)
    return distribute(V)


####################################################################################################
def BoolMult( opr1, opr2 ): # BoolMult('a*b*c','b*d'), dont allow DNF, dont allow coef, no '-'
	if opr1 == "" and opr2 != "": result = opr2;
	elif opr2 == "" and opr1 != "": result = opr1;
	elif opr1 == "" and opr2 == "": 
		print "Error! Both operators are empty in BoolMult()!"
		return 
	else:
		list1 = opr1.split('*')
		list2 = opr2.split('*')
		for item in list1:
			if item in list2: pass
			else: list2.append(item)
		list2 = [item for item in list2 if item != '']
		list2.sort()
		result = '*'.join(list2)
		#print "result",result
	return result

####################################################################################################
# outerCoef*(a+b-2*a*b)
def determCoef(Term, outerCoef):
	# determine coef:
	numbers = '-123456789'
	comb = Term.split('*',1)
	if len(comb) == 1: # if is a single variable term or int
		if '-' in Term: 
			coef = -1*outerCoef
			Term = comb[0].replace('-','')
		else: 
			coef = outerCoef
	else:
		tempCoef = comb[0] 
		#determine coefficents:
		if not tempCoef[0] in numbers: #case a
			coef = outerCoef	
		elif tempCoef[0] == '-' and not tempCoef[1] in numbers: #case -a
			coef = -1*outerCoef
			Term = Term.replace('-','')
		else:
			coef = int(tempCoef)*outerCoef
			Term = comb[1]
	#if Term == '1': Term = ""
#	print "term",Term
	return (Term, coef)
#print determCoef('64',1)

'''
distribute()
	newDNFlist = []
	for DNF in DNFList:
		#splitTermList = splitDNF2terms(DNF)
		splitTermList = []
		tempStr = ''
		level = 0
		for char in DNF:
			if char == "(": 
				level += 1
				tempStr += char 
				continue
			elif char == ")":
				level -= 1
				tempStr += char 
				continue
			elif (char == '+' or char == '-') and level == 0:
				splitTermList.append(tempStr)
				tempStr = ''
				if char == '-':
					tempStr += char 
			else:
				tempStr += char 
'''	


####################################################################################################
#only accecpt (a*b*(c+d-2*c*d)) without coef, only allow one pair of brackets in expression!!!!!
def singleAndTermDistr( strExpr ):
	#print strExpr
	# e.g. a*(b+c)*(a+b-2*a*b)
	#multList = strExpr.split('*')
	if not '*(' in strExpr and not ')*' in strExpr:
		result = strExpr[1:-1]
		#print result
	else:
		multList = split_to_multipliers(strExpr)
		#print multList
		#DNFList = []
		#multiplied = []
		origVarMults = ''
		for mult in multList:
			if not "(" in mult: 
				origVarMults = origVarMults+'*'+mult
			else: 
				#DNFList.append(mult[1:-1]) # '(1-a)' --> '1-a'
				DNF = mult[1:-1]
		multiplied = origVarMults[1:]

		tempTupleCoef2 = determCoef(multiplied, 1)
		tempStrExpr2 = tempTupleCoef2[0]
		tempCoef2 = tempTupleCoef2[1]	
		splitTermList = splitDNF2terms(DNF)
		#tempDict = {}

		multiplied1 = []
		for item1 in splitTermList: # 1. [b, c]; 2. [a, b, -2*a*b]
			tempTupleCoef1 = determCoef(item1, 1)
			tempStrExpr1 = tempTupleCoef1[0]
			tempCoef1 = tempTupleCoef1[1]
			#for item2 in multiplied1: # 1. [a]; 2. [a*b, a*c]
			combTerm = BoolMult( tempStrExpr1, tempStrExpr2 )
			combCoef = tempCoef1*tempCoef2
			if combCoef == 1:
				multiplied1.append(combTerm)
			elif combCoef == -1:
				multiplied1.append('-'+combTerm)
			else:
				multiplied1.append(str(combCoef)+'*'+combTerm)
		#print multiplied
		if multiplied1:
			result = '+'.join(multiplied1)
			result = result.replace('+-','-')
	return result
#print singleAndTermDistr('64*(ca0_9+nn0_27-2*ca0_9*nn0_27)')

####################################################################################################

def and_term_substitute(and_term, var2sub, eqn_right):
	#print "andTerm",and_term
	if and_term[0] == '-':
		and_term = and_term[1:]
		var_list = and_term.split('*')
		index = var_list.index(var2sub)
		var_list[index] = '('+eqn_right+')'
		var_list[0]='-'+var_list[0]
	else:
		var_list = and_term.split('*')
		index = var_list.index(var2sub)
		var_list[index] = '('+eqn_right+')'
	#newExpr = distribute('*'.join(var_list))
	newExpr = singleAndTermDistr('*'.join(var_list))
	return newExpr

####################################################################################################

def stackDistr( nonEqnPoly ):
	nonEqnPoly += "+" # b/c this function relies on "+-" to store terms, add "+" at the end of string avoids ommiting the last term
	operators = "+-*"
	brackets = "{[()]}"
	operandStack = []
	operatorStack = []
	operandStr = ""

	bracketCnt = 0
	for ch in nonEqnPoly:
		if ch == "(":
			bracketCnt += 1
	# 1. classify different char types:
	if bracketCnt == 0:
		return  nonEqnPoly.strip("+")
	elif bracketCnt == 1:
		for i in range(len(nonEqnPoly)):
			ch = nonEqnPoly[i]
			if ch in "+-":
				operandStack.append(operandStr)	
				operandStr = ""
				operatorStack.append(ch)
			elif ch == "(":
				#operandStr = ""
				i += 1
				while nonEqnPoly[i] != ")": 
					operandStr += nonEqnPoly[i]
					i += 1
			elif ch == "*":
				if nonEqnPoly[i+1] != "(":
					operandStr += ch
				else:
					operandStack.append(operandStr)
					operandStr = ""
					operatorStack.append(ch)					
			else:
				operandStr += ch
	else:
		for ch in nonEqnPoly:
			if ch in operators:
				operandStack.append(operandStr)	
				operandStr = ""
				operatorStack.append(ch)
			elif ch in brackets:
				continue
			else:
				operandStr += ch
	operatorStack.pop()
	#print operandStack
	#print operatorStack
		
	# 2. implement distribution process:
	if len(operatorStack) == 0:
		return nonEqnPoly
	else:
		while len(operandStack) > 1:
			operand2 = operandStack.pop()
			operand1 = operandStack.pop()
			operator = operatorStack.pop()
			if operator == "+":
				newOperand = operand1+operator+operand2	
				operandStack.append(newOperand)
			elif operator == "-": # swap "+" and "-"
				termList = splitDNF2terms(operand2)
				newList= []
				for term in termList:
					if not "-" in term: newList.append("-"+term)
					else:	newList.append(term.replace("-","+"))
				newOperand2 = "".join(newList)	
				newOperand = operand1+newOperand2
				operandStack.append(newOperand)
			elif operator == "*":
				termTuple1 = determCoef(operand1, 1)
				#print termTuple1
				term1 = termTuple1[0]
				coef1 = termTuple1[1]
				termList = splitDNF2terms(operand2)
				newList = []
				for term in termList:
					termTuple2 = determCoef(term, 1)
					#print termTuple2
					term2 = termTuple2[0]
					coef2 = termTuple2[1]
					term = BoolMult( term1, term2 )
					coef = str(coef1*coef2)
					newList.append(coef+"*"+term)
				#print newList
				newOperand = "+".join(newList)
				newOperand = newOperand.replace("+-","-")
				#print newOperand
				operandStack.append(newOperand)
	return operandStack.pop()

'''
for i in range(40000):
	stackDistr("1-2+a*b*(a-b)")
	#distribute("1-2+a*b*(a-b)")
print "Finished"
'''

