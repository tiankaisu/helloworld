#!/usr/bin/python 
# Duo Liu
# Nov 2014


'''
1. Levelization starts from each PO bit;
2. Levelization levelizes the nodes which have the smallest level in the candidate level_dict;
3. Store nodes as int
from. 4 Level LSB, leads to same result, but saves mem a lot.
'''

#from multiprocessing import Process, Queue
from unroll_lib import *
import argparse
import re
import sys
import string 
import cProfile
import time
import dis
import copy

#inp_len = args.input_length


############################################################
####################################################       #
#                                                   #     #
# Below is how to levelize gates  # # #
#      									            #     #
####################################################       #
############################################################


###############################################################################
# function definition:
###############################################################################
class builDicts:
	'Build initial dictionaries: eqn_rela_dict and eqn_expr_dict.'
	def __init__(self, buf_in, int2varDict, var2intDict):
		self.buf_in = buf_in
		self.int2varDict = int2varDict
		self.var2intDict = var2intDict

	# not used in this program
	def determineGateType(self, eqnStr ):
		if not '*' in eqnStr and not '-' in eqnStr: gateType = "BUF"
		elif not '*' in eqnStr: gateType ="INV"
		elif not '-' in eqnStr: gateType = "AND"
		elif not '2*' in eqnStr: gateType = "OR"
		else: gateType = "XOR"
		return gateType

	def build_dict(self):
		# build dictionary for equation pool:
		# eqn_expr_dict = {'v1':'v1=v2+v3', ... }
		# eqn_rela_dict = {'v1':['v2','v3'], ... }
		print "\nBuilding dictionary for equation pool ... ... "
		varCnt = max(self.int2varDict)
		eqn_rela_dict = {}
		eqn_expr_dict = {}
		#eqn_gate_type = {}
		for i in range(0,len(self.buf_in)): 
			eqn = self.buf_in[i]
			if '=' in eqn and not '#' in eqn:
				match = re.search(r'(.*)=(.*)',eqn)	
				eqn_left = match.group(1)
				if not eqn_left in self.var2intDict:	
					varCnt += 1				
					self.int2varDict[varCnt]=eqn_left
					self.var2intDict[eqn_left]=varCnt
				eqn_right = distribute(match.group(2))
				#eqn_right = match.group(2)
				vars_in_right = []
				split_terms = splitDNF2terms(eqn_right)
				for term in split_terms:
					if term != '1':
						#multipliers = split_to_multipliers(term)
						multipliers = term.split('*')
						for mult in multipliers:
							mult = mult.strip("-")
							if not mult in self.var2intDict:
								varCnt += 1
								self.int2varDict[varCnt]=mult
								self.var2intDict[mult]=varCnt
							if mult in vars_in_right: pass
							elif mult != '1'  and mult != "2": 							
								vars_in_right.append(mult)
				parentVars = [self.var2intDict[var] for var in vars_in_right]
				eqn_rela_dict[self.var2intDict[eqn_left]] = parentVars
				eqn_expr_dict[self.var2intDict[eqn_left]] = eqn_left+'='+eqn_right # after simplification
				#gateType = determineGateType( eqn_expr_dict[eqn_left] )
				#eqn_gate_type[eqn_left] = gateType
		#return (eqn_rela_dict, eqn_expr_dict, eqn_gate_type)
		return (eqn_rela_dict, eqn_expr_dict, self.int2varDict, self.var2intDict)



###############################################################################

#@profile
class gateLevelization:
	'Levelize gates in circuit according to their distances to POs.'


	def __init__(self, pos, eqn_rela_dict, int2varDict):
		self.pos = pos
		self.eqn_rela_dict = eqn_rela_dict
		self.int2varDict = int2varDict

	def preparationSteps(self):
		##########################
		# STEP 1. INITIALIZATION:
		##########################
		gateNum = len(self.eqn_rela_dict)
		nodes = [] # stores all nodes 
		edges = [] 
		for node in self.eqn_rela_dict:
			nodes.append(node)
			parents = self.eqn_rela_dict[node]
			for parent in parents:
				edges.append((parent,node))
		edgeNum = len(edges)	
		##### 1.1 build adjacency list = {source : [output1, output2], ....}, record the fanouts:
		adjacency_dict = {}
		for edge in edges:
			#print "edge",edge
			if edge[0] in adjacency_dict:
				#print edge[0],adjacency_dict[edge[0]]
				tempList = adjacency_dict[edge[0]][:]
				tempList.append(edge[1])
				adjacency_dict[edge[0]] = tempList
				#print edge[0],adjacency_dict[edge[0]]
			else:
				adjacency_dict[edge[0]] = [edge[1]]
		##### 1.2 build dictionaries to record node level:
		##### disGrpDict = {0:[n1, n2], 1:...}, 
		##### group together vars with same distance to source, at the beginning all dis = -infinity
		##### nodeDisDict = {n1:0, n2:0, ...}, at the beginning ni:float('-inf')
		##### list distance to source of each var, at the beginning all dis = -infinity
		disGrpDict = {}
		nodeDisDict = {}
		#temp = []
		for node in nodes:		
			if float('-inf') in disGrpDict:
				disGrpDict[float('-inf')][node] = None
			else:
				disGrpDict[float('-inf')] = {}				
				disGrpDict[float('-inf')][node] = None
			nodeDisDict[node] = float('-inf')
		return (disGrpDict, nodeDisDict, gateNum, edgeNum, adjacency_dict)
		#print disGrpDict,nodeDisDict



	def updateDictionary(self, targ, parent, nodeDisDict, disGrpDict, level_dict, minLevel):
		oldLevel = nodeDisDict[parent]
		targLevel = nodeDisDict[targ]
		newLevel = (targLevel+1) if targLevel+1>oldLevel else oldLevel	
		#newLevel = max(targLevel+1, oldLevel)
		if newLevel > oldLevel: # need update data
			nodeDisDict[parent] = newLevel
			# rmv parent node from oldLevel list:
			del disGrpDict[oldLevel][parent]
			if newLevel in disGrpDict:
				# add parent node to newLevel list:
				disGrpDict[newLevel][parent] = None
			else:
				disGrpDict[newLevel] = {}				
				disGrpDict[newLevel][parent] = None
		# add new targ
		level_dict[parent] = newLevel
		return (nodeDisDict, disGrpDict, level_dict)

	def parentLevel(self, parentList, nodeDisDict):
		tempEdgeList = []
		tempDict = {}
		for var1 in parentList:
			if var1 in nodeDisDict:
				subList = self.eqn_rela_dict[var1]
				flag = False
				for var2 in parentList:
					if var2 in subList: 
						flag = True
						tempEdge = (var2, var1)
						tempEdgeList.append(tempEdge)
					else: continue
				if flag == False:
					tempDict[var1]=1
		while len(tempEdgeList) != 0:
			for item in tempEdgeList:
				if item[0] in tempDict:
					tempDict[item[1]] = tempDict[item[0]]+1
					tempEdgeList.remove(item)
				else: continue
		returnList = []
		for item in tempDict:
			returnSet = (tempDict[item], item)
			returnList.append(returnSet)
		returnList.sort()
		return returnList
					


	#@profile
	def gate_levelization(self, disGrpDict, nodeDisDict):
		'''
		this level_dict is different from the returned one.
		level_dict, this one just stores temp candidate nodes to level
		'''
		level_dict = {} 
		#######################################
		# STEP 2. iteratively traverse the graph starting from each PO
		#######################################	
		z=self.pos.keys()
		z.reverse()
		for poi in z:
			print "Levelizatoin from", self.int2varDict[poi], "starts ->",
			##### 2.1. determine the proper level number for each PO
			poiLevel = nodeDisDict[poi]
			#del disGrpDict[poiLevel][poi]
			if poiLevel == float('-inf'):
				nodeDisDict[poi] = 0
				level_dict[poi] = 0
				if 0 in disGrpDict:
					disGrpDict[0][poi] = None
				else:
					disGrpDict[0] = {poi : None}
					#disGrpDict[0][poi] = None
				del disGrpDict[poiLevel][poi]
			else:
				level_dict[poi] = poiLevel
			#print level_dict, '->'

			##### 2.2 MAIN WHILE LOOP (loop once for each PO)
			while level_dict != {}:
				#### 2.2.1. determin the minimum level number in level_dict:
				#### level_dict strores candidate targets.
				minLevel = min(level_dict.values())
				#### 2.2.2. from node library select nodes that have minimul level:
				targets1 = disGrpDict[minLevel].keys()[:]
				#### 2.2.3. make sure the visited target is not visited again.
				# e.g. level_dict[level] = a,b,c; targets1 = a,c,d => targets = a,c
				targets = [targ for targ in targets1 if targ in level_dict] 
				#minLevel = min(level_dict.values())
				#targets = [targ for targ in level_dict if level_dict[targ] == minLevel]
				#### 2.2.4. for each new target, assign level number to its parents
				for targ in targets:
					parents_list = []
					parents_list = self.eqn_rela_dict[targ]
					if len(parents_list) == 1:
						parent = parents_list[0]
						if parent in nodeDisDict:
							tuple = self.updateDictionary(targ, parent, nodeDisDict, disGrpDict, level_dict, minLevel)
							nodeDisDict = tuple[0]
							disGrpDict = tuple[1]
							level_dict = tuple[2]
					# we assume there is not loop in the ckt
					else: # means there are more than 1 input signal
						tempList = self.parentLevel(parents_list, nodeDisDict) # levelize the parents first
						for parSet in tempList: # parSet = (level, parent)
							parent = parSet[1]
							if parent in nodeDisDict:
								oldLevel = nodeDisDict[parent]
								targLevel = nodeDisDict[targ]
								newLevel = (targLevel+parSet[0]) if targLevel+parSet[0]>oldLevel else oldLevel
								if newLevel > oldLevel: # need update data
									nodeDisDict[parent] = newLevel
									del disGrpDict[oldLevel][parent]
									if newLevel in disGrpDict:
										disGrpDict[newLevel][parent] = None
									else:
										disGrpDict[newLevel] = {}				
										disGrpDict[newLevel][parent] = None
								level_dict[parent] = newLevel
					del level_dict[targ]	
			print "Levelizatoin from", self.int2varDict[poi], "Finished"
		return disGrpDict


########################################################
# main function starts here!
#
# 1. Convert verilog file to unordered equations
########################################################
#@profile
def eqnLevel(buf_eqn):
	stt = time.time()
	sigOut = buf_eqn[0]
	del buf_eqn[0]

	# get index for PO bits:
	poList = splitDNF2terms(sigOut)
	pos = {}
	int2varDict = {}
	var2intDict = {}
	varCnt = 0
	for po in poList:
		poComb = determCoef(po,1)
		coef = poComb[1]
		mono = poComb[0]
		subVars = mono.split('*')
		for var in subVars:
			if not var in pos: 
				varCnt += 1
				int2varDict[varCnt]=var
				pos[varCnt] = var		
				var2intDict[var]=varCnt
						
	print len(pos),"primary output bits found."
	print int2varDict	###############################################################################
	# building a dictionary stores all eqns with enq_left as keys
	###############################################################################
	firstBuild = builDicts(buf_eqn, int2varDict, var2intDict)	
	tuple = firstBuild.build_dict()
	eqn_rela_dict = tuple[0]
	eqn_expr_dict = tuple[1]
	int2varDict = tuple[2]
	var2intDict = tuple[3]
	###############################################################################
	# Levelization from POs:
	###############################################################################



	levelization = gateLevelization(pos, eqn_rela_dict, int2varDict)
	prepTup = levelization.preparationSteps()
	#return (disGrpDict, nodeDisDict, gateNum, edgeNum)
	disGrpDict = prepTup[0]
	nodeDisDict = prepTup[1]
	adjacency_dict = prepTup[4]
	gateNum = prepTup[2]
	edgeNum = prepTup[3]
	print "Initialization Finished!!!"
	print gateNum,"nodes found."
	print edgeNum,"edges found."	
	interDict = levelization.gate_levelization(disGrpDict, nodeDisDict)

	
	# optimization 4: tuning gates within each level:
	# move eqn with PI as parent to the top of level
	print "\nTuning gates within level ... ..."
	maxLevel = max(interDict)
	finalDict = {}
	for value in range(maxLevel+1):
		sub_level = {}
		subList = interDict[value]
		for item in subList: # tune order within level = value
			parentList = eqn_rela_dict[item]
			significance = 0
			for parent in parentList:
				if 'n' in int2varDict[parent]: continue
				else: significance += 1
			sub_level[item] = significance
		finalDict[value] = sub_level
	

	gateCnt = 0
	leveledGates = []
	buf_out = []
	buf_out.append(sigOut)
	#minLevel = max(level_dict2.values())
	for level in range(maxLevel+1):
		buf_out.append("Level "+str(level)) # add the level number
		sub_dict = finalDict[level]
		gateCnt += len(sub_dict)
		if sub_dict != {}:
			submax = max(sub_dict.values())
			for sublevel in range(submax+1,-1,-1):
				for item in sub_dict:
					if sub_dict[item] == sublevel:
						buf_out.append(eqn_expr_dict[item])
	print "Levelization is finished!!! ^_^\n"
	print "Derived ",len(finalDict),"levels."
	print "Finally",gateCnt,'/',gateNum,"gates levelized."
	print "All gates are levelized? (y/n)"
	end = time.time()
	perf = end-stt
	print '\n', round(perf,3), "seconds used for leveliaztion."

	ans = raw_input(">>> ")
	if ans == ('n' or 'N'):
		omittedGates = []
		for term in eqn_expr_dict:
			if not eqn_expr_dict[term] in buf_out:
				omittedGates.append(eqn_expr_dict[term])
		print len(omittedGates),'are ommitted in the levelization process:',omittedGates
	#print buf_out,len(buf_out)
	elif ans == ('y' or 'Y'):	
		outxt = '\n'.join(buf_out)
		outfilename = sys.argv[1].replace('.txt','').replace('.eqn','')+'-levelized.eqn'
		print "Levelized eqn file is stored into '",outfilename,"'."
		outfile = open(outfilename,'w')
		outfile.write(outxt)
		outfile.close()






#########################################################
#
# MAIN FUNCTION
#
#########################################################
if __name__ == "__main__":
	parser = argparse.ArgumentParser(usage='python  eqn_level_order.py [-h] <input.eqn> ', description='Levelize gates in circuit. Output will be generated into input-levelized.eqn file.',)
	parser.add_argument('<input_file>', help='disordered eqn file.')
	#parser.add_argument('<output>', help='Out file to store reodered gates after levelization.')
	args = parser.parse_args()	
	while True:
		try:
			infile = open(sys.argv[1])
		except:
			print "Invalid input file! Please Check!!!"
			break
		intxt = infile.read()
		infile.close()
	
		print "\nStart reordering equations......"

		buf_intxt = intxt.split('\n')
		buf_eqn = [term.replace('\r','').replace(' ','') for term in buf_intxt]
		# reverse gates gg (from PIto_PO to PO_to_PI), to facilitate our unroll tool --> PROVED NO MUCH MEANING!!
		#buf_gates.reverse()
		gateCnt = 0
		for line in buf_eqn:
			if '=' in line:		
				gateCnt += 1
		print "Number of gates read in =", gateCnt

		eqnLevel(buf_eqn)


		break






