#!/usr/bin/python 
# Duo Liu
# Oct 29 2014


#from multiprocessing import Process, Queue
from unroll_lib import *
import argparse
import re
import sys
import string 
import cProfile

parser = argparse.ArgumentParser(usage='python  eqn_level_order.py [-h] <input.eqn> <output.eqn>', description='Levelize gates in circuit.',)
#parser.add_argument('input_length', help='Input equations that will be used', type=int)
parser.add_argument('<input_file>', help='disordered eqn file.')
parser.add_argument('<output>', help='Out file to store reodered gates after levelization.')
#parser.add_argument('-v', help='Work in verbose mode, convert complex gates into simple 2-input gates.')
args = parser.parse_args()
#inp_len = args.input_length

# not used in this program
def determineGateType( eqnStr ):
	if not '*' in eqnStr and not '-' in eqnStr: gateType = "BUF"
	elif not '*' in eqnStr: gateType ="INV"
	elif not '-' in eqnStr: gateType = "AND"
	elif not '2*' in eqnStr: gateType = "OR"
	else: gateType = "XOR"
	return gateType


############################################################
####################################################       #
#                                                   #     #
# Below is how to convert verilog to equation file:  # # #
#      									            #     #
####################################################       #
############################################################


###############################################################################
# function definition:
###############################################################################

def build_dict(buf_in):
	# build dictionary for equation pool:
	# eqn_expr_dict = {'v1':'v1=v2+v3', ... }
	# eqn_rela_dict = {'v1':['v2','v3'], ... }
	print "\nBuilding dictionary for equation pool ... ... "
	eqn_rela_dict = {}
	eqn_expr_dict = {}
	#eqn_gate_type = {}
	for i in range(0,len(buf_in)): 
		eqn = buf_in[i]
		if '=' in eqn and not '#' in eqn:
			match = re.search(r'(.*)=(.*)',eqn)	
			eqn_left = match.group(1)
			print match.group(2)
			eqn_right = distribute(match.group(2))
			#eqn_right = match.group(2)
			vars_in_right = []
			split_terms = splitDNF2terms(eqn_right)
			for term in split_terms:
				if term != '1':
					#multipliers = split_to_multipliers(term)
					multipliers = term.split('*')
					for mult in multipliers:
						mult = mult.strip("-")
						if mult in vars_in_right: pass
						elif mult != '1'  and mult != "2": 
							vars_in_right.append(mult)
			eqn_rela_dict[eqn_left] = vars_in_right
			eqn_expr_dict[eqn_left] = eqn_left+'='+eqn_right
			#gateType = determineGateType( eqn_expr_dict[eqn_left] )
			#eqn_gate_type[eqn_left] = gateType
	print "Dependency dictionary is built!!!\n"
	#return (eqn_rela_dict, eqn_expr_dict, eqn_gate_type)
	return (eqn_rela_dict, eqn_expr_dict)

'''
def findCriticalPath():
	subGraph = []
	for edge in edges:
		if edge[0] in level_dict and edge[1] in level_dict:
			subGraph.append(edge)
		

def updateLevelDict(targ, level_dict, eqn_rela_dict):
	if targ in eqn_rela_dict:
		ancestors = eqn_rela_dict[targ]
		for ances in ancestors:
			if ances in level_dict:
				level_dict[ances] = min(level_dict[ances], level_dict[targ]-1)
				level_dict = updateLevelDict(ances, level_dict, eqn_rela_dict)
	return level_dict
'''

###############################################################################

def updateDict(parent, node2disDict, dis2nodeDict, level_dict, minLevel):
	oldValue = node2disDict[parent]
	newValue = max(minLevel+1, oldValue)					
	if newValue > oldValue: # need update data
		node2disDict[parent] = newValue
		oldList = dis2nodeDict[oldValue]
		oldList.remove(parent)
		dis2nodeDict[oldValue] = oldList
		if newValue in dis2nodeDict:
			newList = dis2nodeDict[newValue]
			newList.append(parent)
			dis2nodeDict[newValue] = newList
		else:
			newList =[]
			newList.append(parent)
			dis2nodeDict[newValue] = newList
	# add new targ
	level_dict[parent] = newValue
	return (node2disDict, dis2nodeDict, level_dict)


###############################################################################

#@profile
def gate_levelization(gateNum, pos, eqn_rela_dict, level_dict):
	##########################
	# STEP 1. INITIALIZATION:
	##########################
	nodes = [] # stores all nodes which have 
	edges = [] 
	for node in eqn_rela_dict:
		nodes.append(node)
		parents = eqn_rela_dict[node]
		for parent in parents:
			edges.append((parent,node))

	##### 1.1 build adjacency list = {source : [output1, output2], ....}, record the fanouts:
	adjacency_dict = {}
	for edge in edges:
		#print "edge",edge
		if edge[0] in adjacency_dict:
			#print edge[0],adjacency_dict[edge[0]]
			tempList = adjacency_dict[edge[0]][:]
			tempList.append(edge[1])
			adjacency_dict[edge[0]] = tempList
			#print edge[0],adjacency_dict[edge[0]]
		else:
			adjacency_dict[edge[0]] = [edge[1]]

	##### 1.2 build dictionaries to record node level:
	##### dis2nodeDict = {0:[n1, n2], 1:...}
	##### node2disDict = {n1:0, n2:0, ...}
	dis2nodeDict = {}
	node2disDict = {}
	temp = []
	for node in nodes:		
		temp.append(node)
		dis2nodeDict[float('-inf')] = temp
		node2disDict[node] = float('-inf')
	#print dis2nodeDict,node2disDict
	print "Initialization Finished!!!"
	print gateNum,"nodes found."
	print len(edges),"edges found."

	#######################################
	# STEP 2. iteratively traverse the graph starting from each PO
	#######################################	
	for pi in pos:
		#leveled_gates = []
		##### 2.1. determine the proper level number for each PO
		if node2disDict[pi] == float('-inf'):
			node2disDict[pi] = 0
			level_dict[pi] = 0
			if 0 in dis2nodeDict:
				firstLevel = dis2nodeDict[0]
				firstLevel.append(pi)
				dis2nodeDict[0] = firstLevel
			else:
				dis2nodeDict[0] = [pi]	
		else:
			level_dict[pi] = node2disDict[pi]
		#tempNodes = nodes[:]
		#print level_dict

		##### 2.2 MAIN WHILE LOOP (loop once for each PO)
		while level_dict != {}:
			#### 2.2.1. determin the minimum level number in level_dict:
			#### level_dict strores candidate targets.
			minLevel = min(level_dict.values())
			#### 2.2.2. from node library select nodes that have minimul level:
			targets = dis2nodeDict[minLevel]	
			#### 2.2.3. make sure the visited target is not visited again.
			targets = [targ for targ in targets if targ in level_dict]
			#### 2.2.4. for each new target, assign level number to its parents
			#### if 
			for targ in targets:
				parents_list = []
				parents_list = eqn_rela_dict[targ]
				if len(parents_list) == 1:
					parent = parents_list[0]
					if parent in node2disDict:
						tuple = updateDict(parent, node2disDict, dis2nodeDict, level_dict, minLevel)
						node2disDict = tuple[0]
						dis2nodeDict = tuple[1]
						level_dict = tuple[2]
				# we assume there is not loop in the ckt
				elif len(parents_list) == 2:
					parent1 = parents_list[0]
					parent2 = parents_list[1]
					#### !!!!!! the use of adjacency_dict is very important, saves a lot of time!!!!
					if parent1 in adjacency_dict[parent2]:   	#####
						testEdge = (parent2,parent1)          		#### means the parents are connected!
					elif parent2 in adjacency_dict[parent1]:	#####
						testEdge = (parent1,parent2)
					else:
						testEdge = '' # means 2 parents are independent
						for parent in parents_list:
							if parent in node2disDict:
								oldValue = node2disDict[parent]
								newValue = max(minLevel+1, oldValue)					
								if newValue > oldValue: # need update data
									node2disDict[parent] = newValue
									oldList = dis2nodeDict[oldValue]
									oldList.remove(parent)
									dis2nodeDict[oldValue] = oldList
									if newValue in dis2nodeDict:
										newList = dis2nodeDict[newValue]
										newList.append(parent)
										dis2nodeDict[newValue] = newList
									else:
										newList =[]
										newList.append(parent)
										dis2nodeDict[newValue] = newList
								# add new targ
								level_dict[parent] = newValue
					if testEdge != '':		
						#del level_dict[targ]
						#nodes.remove(targ)
						for i in range(len(testEdge)-1,-1,-1):
							#parent = Edge[i]	
							if parent in node2disDict:
								oldValue = node2disDict[parent]
								if i == 1:
									newValue = max(minLevel+1, oldValue)		
								elif i == 2:
									newValue = max(minLevel+2, oldValue)											
								if newValue > oldValue: # need update data
									node2disDict[parent] = newValue
									oldList = dis2nodeDict[oldValue]
									oldList.remove(parent)
									dis2nodeDict[oldValue] = oldList
									if newValue in dis2nodeDict:
										newList = dis2nodeDict[newValue]
										newList.append(parent)
										dis2nodeDict[newValue] = newList
									else:
										newList =[]
										newList.append(parent)
										dis2nodeDict[newValue] = newList			
								level_dict[parent] = newValue
				del level_dict[targ]	
				#if not targ in leveled_gates:			
				#leveled_gates.append(targ)						
		#print "Levelization starts from",pi,"finished."
	#print len(level_dict),'/',len(eqn_rela_dict)	
	#print dis2nodeDict
	return dis2nodeDict

'''
			for descendant in descendant_lsit:
				if descendant in nodes: # unvisited
					oldValue = node2disDict[descendant]
					newValue = max(minLevel-1, oldValue)					
					if newValue > oldValue: # need update data
						node2disDict[parent] = newValue
						oldList = dis2nodeDict[oldValue]
						oldList.remove(parent)
						if newValue in dis2nodeDict:
							newList = dis2nodeDict[newValue]
							newList.append(parent)
							dis2nodeDict[newValue] = newList
						else:
							newList =[]
							newList.append(parent)
							dis2nodeDict[newValue] = newList
'''
		



'''					
	nodesInSubgraph = targets[:]
	subGraph = []
	while len(nodes) != 0:
		parent_list = []
		relatedEdges = []
		while targets != []:
			targ = targets.pop()
			if targ in eqn_rela_dict:	# if targ = pi, it is not in eqn_rela_dict
				# find parents for target, set them as targets for nxt round
				parents = eqn_rela_dict[targ]
				for parent in parents:		
					if not parent in nodesInSubgraph: 
						nodesInSubgraph.append(parent)
					if not parent in parent_list:
						parent_list.append(parent)
	
	tempEdges = edges[:]
	for edge in edges:
		if edge[0] in nodesInSubgraph and edge[1] in nodesInSubgraph:
			subGraph.append(edge)
			tempEdges.remove(edge)
	edges = tempEdges[:]


		#redefine targ level value:
		for edge in relatedEdges:
			level_dict[edge[0]] = level_dict[edge[1]] - 1	
		for edge in relatedEdges:	
			level_dict = updateLevelDict(edge[0], level_dict, eqn_rela_dict)		
		print len(level_dict),"/",gateNum,"gates levelized.\n"
		# set parents for targs as new targets to be levelized	
		#print "length of parent_list",len(parent_list)	
		for edge in relatedEdges:
			targets.append(edge[0])			
	#print "Levelize from",original,"---> Levelized gates ",len(level_dict),"/",len(eqn_rela_dict),"\n"

	return level_dict
'''


########################################################
# main function starts here!
#
# 1. Convert verilog file to unordered equations
########################################################
#@profile
def eqnLevel():
	try:
		infile = open(sys.argv[1])
	except:
		print "Invalid input file! Please Check!!!"
		return
	#infile = open(sys.argv[1])
	intxt = infile.read()
	infile.close()
	

	print "\nStart reordering equations......"


	buf_intxt = intxt.split('\n')
	buf_eqn = [term.replace('\r','').replace(' ','') for term in buf_intxt]
	# reverse gates gg (from PIto_PO to PO_to_PI), to facilitate our unroll tool --> PROVED NO MUCH MEANING!!
	#buf_gates.reverse()
	print "Number of gates read in =",len(buf_eqn)
	sigOut = buf_eqn[0]
	print "output signature =",sigOut
	del buf_eqn[0]


	###############################################################################
	# building a dictionary stores all eqns with enq_left as keys
	###############################################################################
	tuple = build_dict(buf_eqn)
	eqn_rela_dict = tuple[0]
	eqn_expr_dict = tuple[1]
	gateNum = len(eqn_rela_dict)
	#eqn_gate_type = tuple[2]
	#print "eqn_rela_dict:\n",eqn_rela_dict,len(eqn_rela_dict),'\n'
	#print "eqn_expr_dict:\n",eqn_expr_dict,len(eqn_expr_dict),'\n'


	###############################################################################
	# Levelization from POs:
	###############################################################################

	# get index for PO bits:
	poList = splitDNF2terms(sigOut)
	pos = []
	for po in poList:
		poComb = determCoef(po,1)
		coef = poComb[1]
		mono = poComb[0]
		subVars = mono.split('*')
		for var in subVars:
			if not var in pos: pos.append(var)
	level_dict = {}
	'''
	poIndex = ""
	for char in poList[0]:
		if char in string.ascii_lowercase or char in string.ascii_uppercase or char == "_":
			poIndex += char
	print "Get primary output index is '",poIndex,"'\n"
	#level_dict2 = level_dict1
	outBits = len(poList)

	# optimization 1: simply level gates w.r.t. dependency
	level_dict = {}
	print "Begin to levelize gate  ... ..."
	pos = []
	# get primary output bits
	for i in range (outBits-1,-1,-1):
		initial = poIndex+str(i)
		pos.append(initial)
	'''
	print "Primary output bits:",pos
	
	level_dict = gate_levelization(gateNum, pos, eqn_rela_dict, level_dict)

	'''
	gateCnt = 0
	buf_out = []
	buf_out.append(sigOut)
	maxLevel = max(level_dict)
	#minLevel = max(level_dict2.values())
	for level in range(maxLevel+1):
		buf_out.append("Level "+str(level)) # add the level number
		sub_dict = level_dict[level]
		gateCnt += len(sub_dict)
		for item in sub_dict:
			buf_out.append(eqn_expr_dict[item])
	print "Levelization is finished!!! ^_^\n"
	print "Derived ",len(level_dict),"levels."
	print gateCnt,'/',gateNum,"gates levelized."
	'''


	'''
	level_dict2 = {}
	for level in level_dict:
		leveledList = level_dict[level]
		for var in leveledList:
			level_dict2[var] = level
	'''

	'''
	# optimization 2: move eqns sharing parents to the largets level:
	print "\nTuning gates between levels ... ..."
	newDict = eqn_rela_dict.copy()
	sameParentList = []
	while len(newDict) > 0:
		for item in newDict:
			subList = [] # store a set of vars share parents
			parSet = set(newDict[item]) # use set to make ['a','b'] == ['b','a']
			for another in newDict:
				if parSet == set(newDict[another]): # there is another var has same parents
					subList.append(another)
			for item in subList:
				del newDict[item]
			sameParentList.append(subList)
			break # loop from new reduced newDict
	#print sameParentList

	for subList in sameParentList:
		if len(subList) == 1: continue # single var has no common parents with any other
		else:
			subMaxLevel = 0
			for item in subList: # get the max level of signals sharing parents
				tempLevel = level_dict2[item]		
				subMaxLevel = max(subMaxLevel,tempLevel)
			for item in subList: # move all signals sharing parents to the largest level
				level_dict2[item] = subMaxLevel
	print "Finished!!\n"
	'''
	
	# optimization 4: tuning gates within each level:
	# processing tmpLevelDict and build final finaLevel
	# rearrange items which belong to the same level:
	print "\nTuning gates within level ... ..."
	maxLevel = max(level_dict)
	finaLevel = {}
	for value in range(maxLevel+1):
		sub_level = {}
		subList = level_dict[value]
		for item in subList: # tune order within level = value
			parentList = eqn_rela_dict[item]
			significance = 0
			for parent in parentList:
				if 'n' in parent: continue
				else: significance += 1
			sub_level[item] = significance
		finaLevel[value] = sub_level
	
	# generate output signature
	gateCnt = 0
	leveledGates = []
	buf_out = []
	buf_out.append(sigOut)
	#minLevel = max(level_dict2.values())
	for level in range(maxLevel+1):
		buf_out.append("Level "+str(level)) # add the level number
		sub_dict = finaLevel[level]
		gateCnt += len(sub_dict)
		submax = max(sub_dict.values())
		for sublevel in range(submax+1,-1,-1):
			for item in sub_dict:
				#print item
				if sub_dict[item] == sublevel:
					buf_out.append(eqn_expr_dict[item])
	print "Levelization is finished!!! ^_^\n"
	print "Derived ",len(finaLevel),"levels."
	print "Finally",gateCnt,'/',gateNum,"gates levelized."
	

	#print buf_out,len(buf_out)



	outxt = '\n'.join(buf_out)
	outfile = open(sys.argv[2],'w')
	outfile.write(outxt)
	outfile.close()

if __name__ == "__main__":
	eqnLevel()






